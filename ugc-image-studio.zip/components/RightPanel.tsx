
import React, { useState } from 'react';
import type { HistoryItem } from '../types';
import { DownloadIcon, RefreshCwIcon, ClipboardIcon, XIcon } from './icons';

interface RightPanelProps {
  latestImages: string[];
  history: HistoryItem[];
}

export const RightPanel: React.FC<RightPanelProps> = ({ latestImages, history }) => {
  const [lightboxItem, setLightboxItem] = useState<HistoryItem | null>(null);

  const handleDownload = (imageUrl: string) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `generated-image-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  return (
    <aside className="w-[380px] bg-gray-950 flex flex-col h-full border-l border-gray-800">
      <div className="p-4 flex-shrink-0">
        <h2 className="text-sm font-semibold uppercase text-gray-500 tracking-wider mb-3">Output</h2>
        <div className="aspect-auto bg-black/20 rounded-lg overflow-hidden">
          {latestImages.length > 0 ? (
             <div className={`grid ${latestImages.length > 1 ? 'grid-cols-2' : 'grid-cols-1'} gap-2`}>
                {latestImages.map((img, idx) => (
                    <div key={idx} className="relative group">
                        <img src={img} alt={`Generated Output ${idx + 1}`} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                           <button onClick={() => handleDownload(img)} className="p-2 bg-white/20 rounded-full text-white hover:bg-white/30"><DownloadIcon className="w-5 h-5"/></button>
                        </div>
                    </div>
                ))}
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 text-gray-600 text-sm">
              Generated images will appear here
            </div>
          )}
        </div>
      </div>

      <div className="p-4 flex-1 flex flex-col min-h-0">
        <h2 className="text-sm font-semibold uppercase text-gray-500 tracking-wider mb-3">History</h2>
        <div className="flex-1 overflow-y-auto pr-1 -mr-4">
          {history.length > 0 ? (
            <div className="grid grid-cols-2 gap-2">
              {history.map(item => (
                <div key={item.id} className="relative aspect-square group cursor-pointer" onClick={() => setLightboxItem(item)}>
                  <img src={item.generatedImages[0]} alt="History thumbnail" className="w-full h-full object-cover rounded-md" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-md"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-600 text-sm">
              No history yet
            </div>
          )}
        </div>
      </div>
      {lightboxItem && <Lightbox item={lightboxItem} onClose={() => setLightboxItem(null)} onDownload={handleDownload} />}
    </aside>
  );
};


const Lightbox: React.FC<{item: HistoryItem; onClose: () => void; onDownload: (url: string) => void;}> = ({ item, onClose, onDownload }) => {
    return (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center" onClick={onClose}>
            <div className="bg-gray-900 rounded-lg max-w-4xl w-full max-h-[90vh] flex flex-col md:flex-row gap-4 p-4 overflow-hidden" onClick={e => e.stopPropagation()}>
                <div className="flex-1 relative">
                    <img src={item.generatedImages[0]} alt="Full resolution" className="w-full h-full object-contain" />
                    <button onClick={onClose} className="absolute top-2 right-2 p-1.5 bg-black/50 text-white rounded-full hover:bg-black/70">
                        <XIcon className="w-5 h-5"/>
                    </button>
                </div>
                <div className="w-full md:w-80 flex-shrink-0 flex flex-col space-y-4">
                    <div className="p-3 bg-gray-800 rounded-md">
                        <h3 className="text-xs uppercase text-gray-500 font-semibold mb-2">Prompt</h3>
                        <p className="text-sm text-gray-300 max-h-24 overflow-y-auto">{item.prompt}</p>
                    </div>
                    <div className="p-3 bg-gray-800 rounded-md">
                        <h3 className="text-xs uppercase text-gray-500 font-semibold mb-2">Reference Images</h3>
                        <div className="grid grid-cols-2 gap-2">
                            {item.referenceImages.map(ref => (
                                <img key={ref.id} src={ref.previewUrl} className="w-full aspect-square object-cover rounded" alt="Reference"/>
                            ))}
                        </div>
                    </div>
                     <div className="flex-1"></div>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                        <button className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold py-2 rounded-md" onClick={() => onDownload(item.generatedImages[0])}>
                            <DownloadIcon className="w-4 h-4" /> Download
                        </button>
                        <button className="flex items-center justify-center gap-2 bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 rounded-md">
                            <ClipboardIcon className="w-4 h-4" /> Copy Prompt
                        </button>
                         <button className="col-span-2 flex items-center justify-center gap-2 bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 rounded-md">
                            <RefreshCwIcon className="w-4 h-4" /> Regenerate
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

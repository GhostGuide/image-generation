
import React, { useState, useCallback, useRef } from 'react';
import type { GenerationSettings, ReferenceImage, AspectRatio, StylePreset, Mode } from '../types';
import { UploadCloudIcon, ChevronDownIcon, XIcon } from './icons';

interface LeftPanelProps {
  settings: GenerationSettings;
  setSettings: React.Dispatch<React.SetStateAction<GenerationSettings>>;
  referenceImages: ReferenceImage[];
  setReferenceImages: React.Dispatch<React.SetStateAction<ReferenceImage[]>>;
}

const DraggableThumbnail: React.FC<{
  image: ReferenceImage;
  index: number;
  onRemove: (id: string) => void;
  onMove: (dragIndex: number, hoverIndex: number) => void;
}> = ({ image, index, onRemove, onMove }) => {
  const ref = useRef<HTMLDivElement>(null);

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>) => {
    e.dataTransfer.setData('text/plain', index.toString());
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const dragIndex = parseInt(e.dataTransfer.getData('text/plain'), 10);
    onMove(dragIndex, index);
  };
  
  return (
    <div 
        ref={ref}
        draggable
        onDragStart={handleDragStart}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        className="relative aspect-square w-full rounded-md overflow-hidden group cursor-move">
      <img src={image.previewUrl} alt="Reference" className="w-full h-full object-cover" />
      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-colors duration-200"></div>
      <button
        onClick={() => onRemove(image.id)}
        className="absolute top-1 right-1 p-0.5 bg-black bg-opacity-50 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity"
      >
        <XIcon className="w-4 h-4" />
      </button>
    </div>
  );
};


export const LeftPanel: React.FC<LeftPanelProps> = ({ settings, setSettings, referenceImages, setReferenceImages }) => {
  const [isAdvancedOpen, setIsAdvancedOpen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = (files: FileList | null) => {
    if (files) {
      const newImages: ReferenceImage[] = Array.from(files)
        .slice(0, 4 - referenceImages.length)
        .map(file => ({
          id: crypto.randomUUID(),
          file,
          previewUrl: URL.createObjectURL(file),
        }));
      setReferenceImages(prev => [...prev, ...newImages]);
    }
  };

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    handleFileChange(e.dataTransfer.files);
  }, [referenceImages.length, setReferenceImages]);

  const handleDragEvents = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setIsDragging(true);
    } else if (e.type === 'dragleave') {
      setIsDragging(false);
    }
  };

  const removeImage = (id: string) => {
    setReferenceImages(prev => prev.filter(img => img.id !== id));
  };
  
  const moveImage = useCallback((dragIndex: number, hoverIndex: number) => {
    setReferenceImages(prev => {
        const newImages = [...prev];
        const [draggedItem] = newImages.splice(dragIndex, 1);
        newImages.splice(hoverIndex, 0, draggedItem);
        return newImages;
    });
  }, [setReferenceImages]);


  const updateSetting = <K extends keyof GenerationSettings>(key: K, value: GenerationSettings[K]) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <aside className="w-[320px] bg-gray-950 flex flex-col h-full border-r border-gray-800 p-4 space-y-4 overflow-y-auto">
      <div>
        <div
          onDrop={handleDrop}
          onDragEnter={handleDragEvents}
          onDragOver={handleDragEvents}
          onDragLeave={handleDragEvents}
          className={`relative border-2 border-dashed rounded-lg p-6 text-center transition-colors duration-200 ${isDragging ? 'border-blue-500 bg-gray-800' : 'border-gray-700 hover:border-blue-600'}`}
        >
          <UploadCloudIcon className="mx-auto h-10 w-10 text-gray-500" />
          <p className="mt-2 text-sm text-gray-400">Drag & drop 1-4 images</p>
          <p className="text-xs text-gray-600">or click to browse</p>
          <input
            type="file"
            multiple
            accept="image/*"
            onChange={e => handleFileChange(e.target.files)}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            disabled={referenceImages.length >= 4}
          />
        </div>
        {referenceImages.length > 0 && (
          <div className="mt-4 grid grid-cols-2 gap-2">
            {referenceImages.map((img, index) => (
              <DraggableThumbnail key={img.id} image={img} index={index} onRemove={removeImage} onMove={moveImage} />
            ))}
          </div>
        )}
      </div>

      <ControlGroup label="Aspect Ratio">
        <Select<AspectRatio>
          value={settings.aspectRatio}
          onChange={val => updateSetting('aspectRatio', val)}
          options={["9:16", "3:4", "4:5", "1:1", "16:9", "Custom"]}
        />
      </ControlGroup>

      <ControlGroup label="Style Preset">
        <ChipSelect<StylePreset>
          value={settings.stylePreset}
          onChange={val => updateSetting('stylePreset', val)}
          options={[ "Pinterest Minimal Studio", "Soft Pastel Aesthetic", "Luxury Editorial", "Outdoor Lifestyle", "High Fashion Runway", "Clean Flatlay", "Jewelry Macro" ]}
        />
      </ControlGroup>
      
      <ControlGroup label="Mode">
        <Toggle<Mode>
          value={settings.mode}
          onChange={val => updateSetting('mode', val)}
          options={["Product Only", "Model Wearing", "Mixed (dynamic)"]}
        />
      </ControlGroup>

      <ControlGroup label="Variant Count">
        <Select<1 | 2 | 4>
          value={settings.variantCount}
          onChange={val => updateSetting('variantCount', val)}
          options={[1, 2, 4]}
        />
      </ControlGroup>

      <div>
        <button onClick={() => setIsAdvancedOpen(!isAdvancedOpen)} className="w-full flex justify-between items-center text-sm font-medium text-gray-400 hover:text-white">
          Advanced Options
          <ChevronDownIcon className={`w-4 h-4 transition-transform ${isAdvancedOpen ? 'rotate-180' : ''}`} />
        </button>
        {isAdvancedOpen && (
          <div className="mt-4 space-y-4 pt-2 border-t border-gray-800">
            <ControlGroup label="Seed">
               <input 
                type="text" 
                placeholder="Random"
                value={settings.seed === null ? '' : settings.seed}
                onChange={e => updateSetting('seed', e.target.value === '' ? null : Number(e.target.value.replace(/\D/g,'')))}
                className="w-full bg-gray-800 border border-gray-700 rounded-md px-2 py-1 text-sm focus:ring-1 focus:ring-blue-500 focus:border-blue-500 outline-none"
               />
            </ControlGroup>
             <Slider
              label="Guidance Strength"
              value={settings.guidanceStrength}
              onChange={val => updateSetting('guidanceStrength', val)}
              min={0} max={100} step={1}
            />
             <Slider
              label="Reference Strength"
              value={settings.referenceStrength}
              onChange={val => updateSetting('referenceStrength', val)}
              min={0} max={1} step={0.01}
            />
             <Slider
              label="Temperature"
              value={settings.temperature}
              onChange={val => updateSetting('temperature', val)}
              min={0} max={2} step={0.01}
            />
          </div>
        )}
      </div>
    </aside>
  );
};

const ControlGroup: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
  <div className="space-y-2">
    <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{label}</label>
    {children}
  </div>
);

const Select = <T extends string | number,>({ value, onChange, options }: { value: T, onChange: (value: T) => void, options: T[] }) => (
  <select
    value={value}
    onChange={e => onChange(e.target.value as T)}
    className="w-full bg-gray-800 border border-gray-700 rounded-md px-2 py-1.5 text-sm focus:ring-1 focus:ring-blue-500 focus:border-blue-500 outline-none"
  >
    {options.map(option => <option key={option} value={option}>{option}</option>)}
  </select>
);

const ChipSelect = <T extends string,>({ value, onChange, options }: { value: T, onChange: (value: T) => void, options: T[] }) => (
    <div className="flex flex-wrap gap-2">
      {options.map(option => (
        <button
          key={option}
          onClick={() => onChange(option)}
          className={`px-2.5 py-1 text-xs font-medium rounded-full transition-colors ${
            value === option ? 'bg-blue-600 text-white' : 'bg-gray-800 hover:bg-gray-700'
          }`}
        >
          {option}
        </button>
      ))}
    </div>
);

const Toggle = <T extends string,>({ value, onChange, options }: { value: T, onChange: (value: T) => void, options: T[] }) => (
    <div className="flex bg-gray-800 rounded-md p-0.5 border border-gray-700">
        {options.map(option => (
            <button
                key={option}
                onClick={() => onChange(option)}
                className={`flex-1 text-center text-xs font-semibold py-1 rounded-sm transition-colors ${
                    value === option ? 'bg-gray-600 text-white' : 'text-gray-400 hover:bg-gray-700'
                }`}
            >
                {option}
            </button>
        ))}
    </div>
);

const Slider: React.FC<{label: string; value: number; onChange: (value: number) => void; min: number; max: number; step: number}> = 
({label, value, onChange, min, max, step}) => (
    <div>
        <div className="flex justify-between items-center mb-1">
            <label className="text-sm text-gray-300">{label}</label>
            <span className="text-sm font-mono bg-gray-800 px-1.5 py-0.5 rounded">{value.toFixed(label === 'Reference Strength' || label === 'Temperature' ? 2 : 0)}</span>
        </div>
        <input
            type="range"
            min={min}
            max={max}
            step={step}
            value={value}
            onChange={e => onChange(parseFloat(e.target.value))}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer range-sm accent-blue-500"
        />
    </div>
);

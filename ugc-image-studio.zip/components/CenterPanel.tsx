
import React from 'react';
import type { ReferenceImage, ColorSwatch } from '../types';
import { SparklesIcon, ClipboardIcon, TrashIcon } from './icons';

interface CenterPanelProps {
  referenceImages: ReferenceImage[];
  prompt: string;
  setPrompt: (prompt: string) => void;
  colorSwatches: ColorSwatch[];
  onAutoPrompt: () => void;
  onGenerate: () => void;
  onClearCanvas: () => void;
  isLoading: boolean;
}

export const CenterPanel: React.FC<CenterPanelProps> = ({
  referenceImages,
  prompt,
  setPrompt,
  colorSwatches,
  onAutoPrompt,
  onGenerate,
  onClearCanvas,
  isLoading,
}) => {
  return (
    <main className="flex-1 flex flex-col h-full p-4 md:p-6 bg-gray-900 overflow-y-auto">
      <div className="flex-1 flex items-center justify-center bg-black/20 rounded-lg mb-4 overflow-hidden relative">
        {referenceImages.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 p-2 w-full h-full">
            {referenceImages.map(img => (
              <img key={img.id} src={img.previewUrl} className="w-full h-full object-contain rounded-md" alt="Reference"/>
            ))}
          </div>
        ) : (
          <div className="text-center text-gray-500">
            <p>Upload images to begin</p>
          </div>
        )}
      </div>
      
      {colorSwatches.length > 0 && (
          <div className="mb-4">
              <p className="text-xs font-semibold text-gray-500 uppercase mb-2">Extracted Colors</p>
              <div className="flex gap-2 flex-wrap">
                  {colorSwatches.map(({ hex }) => (
                      <div key={hex} className="flex items-center gap-1.5 bg-gray-800 p-1 rounded-md">
                          <div className="w-4 h-4 rounded" style={{ backgroundColor: hex }}></div>
                          <span className="text-xs font-mono uppercase">{hex}</span>
                      </div>
                  ))}
              </div>
          </div>
      )}

      <div className="bg-gray-800 border border-gray-700 rounded-lg p-3">
        <textarea
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          placeholder="Describe the scene you want to create, or click 'Auto-Generate Prompt'..."
          className="w-full bg-transparent text-gray-200 placeholder-gray-500 resize-none outline-none text-sm h-20"
        />
        <div className="flex items-center justify-between mt-2 pt-3 border-t border-gray-700">
          <div className="flex items-center gap-2">
            <ActionButton icon={<ClipboardIcon className="w-4 h-4"/>} tooltip="Copy Prompt" onClick={() => navigator.clipboard.writeText(prompt)} />
            <ActionButton icon={<TrashIcon className="w-4 h-4"/>} tooltip="Clear Canvas" onClick={onClearCanvas} />
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onAutoPrompt}
              disabled={isLoading || referenceImages.length === 0}
              className="px-4 py-2 text-sm font-semibold text-white bg-gray-700 hover:bg-gray-600 rounded-md flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <SparklesIcon className="w-4 h-4" />
              Auto-Generate Prompt
            </button>
            <button
              onClick={onGenerate}
              disabled={isLoading || referenceImages.length === 0}
              className="px-6 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-md disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Generate
            </button>
          </div>
        </div>
      </div>
    </main>
  );
};

const ActionButton: React.FC<{icon: React.ReactNode; tooltip: string; onClick: () => void;}> = ({ icon, tooltip, onClick }) => (
    <button
        onClick={onClick}
        className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-md relative group"
    >
        {icon}
        <span className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 whitespace-nowrap bg-black text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
            {tooltip}
        </span>
    </button>
);

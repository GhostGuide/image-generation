
import { GoogleGenAI, Modality, Type } from "@google/genai";
import type { ReferenceImage, GenerationSettings, StylePreset } from '../types';

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  // In a real app, you'd handle this more gracefully.
  // Here we assume it's set in the environment.
  console.warn("API_KEY is not set. Please set it in your environment variables.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
};

export const analyzeImages = async (images: ReferenceImage[]): Promise<string> => {
  const imageParts = await Promise.all(images.map(img => fileToGenerativePart(img.file)));

  const prompt = `Analyze these product images meticulously. Extract the following details:
1.  **Product Type:** What is the item? (e.g., 'leather handbag', 'suede ankle boots').
2.  **Silhouette:** Describe its shape and form.
3.  **Material & Texture:** What is it made of? Describe the texture (e.g., 'buttery soft leather', 'coarse woven canvas').
4.  **Patterns & Stitching:** Any visible patterns, prints, or notable stitching details.
5.  **Colors:** Identify the 5 most prominent colors and provide their approximate HEX codes.
6.  **Unique Features:** Mention any distinctive hardware, closures, logos, or design elements.
Provide a concise, detailed summary of these attributes.`;

  const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: { parts: [...imageParts, { text: prompt }] },
  });
  return response.text;
};

export const generateFinalPrompt = async (
  analysis: string,
  userPrompt: string,
  stylePreset: StylePreset,
  settings: GenerationSettings
): Promise<{prompt: string}> => {
  
  const masterSystemPrompt = `You are a NanoBanana UGC Fashion Image System optimized for Whisk-style fast generation. Your task is to synthesize image analysis, a user prompt, and a style preset into a single, powerful, and clean prompt for image generation.

**CRITICAL RULES:**
1.  The final prompt must describe a scene that **preserves the original product 100% unchanged**. The product's attributes from the analysis are sacred.
2.  The prompt should focus on the **environment, cinematic lighting, camera feel, and aesthetic mood**.
3.  Do **NOT** include aspect ratio in the prompt.
4.  You **MUST** output a valid JSON object.

**INPUTS:**
*   **Image Analysis:** ${analysis}
*   **User Prompt:** ${userPrompt || 'None'}
*   **Style Preset:** ${stylePreset}
*   **Mode:** ${settings.mode}

Combine these inputs to generate the final prompt. For example, if the preset is 'Luxury Editorial', the prompt should evoke a high-fashion magazine shoot. If 'Outdoor Lifestyle', it should feel like a brand campaign in nature.`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: masterSystemPrompt,
    config: {
        responseMimeType: "application/json",
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                prompt: {
                    type: Type.STRING,
                    description: "The final, combined prompt for the image generation model."
                }
            }
        }
    }
  });

  try {
    // The response.text is already a parsed JSON object when schema is used
    const parsed = JSON.parse(response.text);
    return parsed;
  } catch (e) {
    console.error("Failed to parse JSON from Gemini:", response.text);
    // Fallback to returning the raw text as the prompt
    return { prompt: response.text };
  }
};

export const generateImages = async (
  prompt: string,
  referenceImages: ReferenceImage[]
): Promise<string[]> => {
  const imageParts = await Promise.all(referenceImages.map(img => fileToGenerativePart(img.file)));

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        ...imageParts,
        { text: prompt },
      ],
    },
    config: {
        responseModalities: [Modality.IMAGE],
    },
  });

  const generatedImages: string[] = [];
  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      const base64ImageBytes: string = part.inlineData.data;
      const imageUrl = `data:${part.inlineData.mimeType};base64,${base64ImageBytes}`;
      generatedImages.push(imageUrl);
    }
  }

  // The model may only return 1 image, so we duplicate it if more variants are requested
  // This is a placeholder for a model that can generate multiple variants
  while(generatedImages.length > 0 && generatedImages.length < 4) {
    generatedImages.push(generatedImages[0]);
  }

  return generatedImages;
};
